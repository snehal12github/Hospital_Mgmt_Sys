<?php
include("navbar.php");






?>
<div class="container-fluid">
	<div class="row">
	<div class="col-sm-2">
		
			
		 
			<br/><br/>
		  <form>
				<a href="admin.php?id=1"  style="color:green"><button type="button" class="btn btn-outline-primary form-control"><i class="fa fa-dashboard"></i> Dashboard</button></a>
			  <br /><br />
			  <a href="admin.php?id=2"  style="color:green" ><button type="button"  class="btn btn-outline-primary form-control"><i class="fa fa-edit"></i>Medicine </button></a>
			  <br /><br />
			  
			   <a href="admin.php?id=3"  style="color:green" ><button type="button"  class="btn btn-outline-primary form-control"><i class="fa fa-edit"></i> Selled </button></a>
			   
			    <br /><br />
			  
			   <a href="admin.php?id=4"  style="color:green" ><button type="button"  class="btn btn-outline-primary form-control"><i class="fa fa-edit"></i>Edit Profile </button></a>
			   
			  <br /><br />
			  
			  
				<a href="logout.php" style="color:green"><button type="button" class="btn btn-outline-primary form-control"><i class="fa fa-power-off"></i> Log Out</button></a>
			  </form>
	

	</div>

	<div class="col-sm-10">
		<br/><br/>
		<?php
		
						$b=$_GET["edit"];
							$select="select * from medicine where id='$b'";
							$q=mysqli_query($con,$select);
							while($a=mysqli_fetch_array($q))
							{
								$id=$a["id"];
								$name=$a["name"];
								$disease=$a["disease"];
								$dis=$a["dis"];
								$p1=$a["p1"];
								$p2=$a["p2"];
								$p3=$a["p3"];
								$price=$a["price"];
								$quentity=$a["quentity"];
								$regtime=$a["regtime"];

								?>

									<div class="col-sm-1">
								</div>
								<div class="col-sm-9">
								<form action="" method="post" enctype="multipart/form-data">
								<div class="row">
									<div class="col-sm-6">
									<label> Enter Medicine Name </label>
									<input class="form-control" value="<?php echo $name; ?>" type="text" name="name"  /><br/>
									</div>

									<div class="col-sm-6">
									<label> Enter Medicine for Which Disease </label>
									<input class="form-control" value="<?php echo $disease; ?>" type="text" name="disease"  /><br/>
									</div>
									
									<div class="col-sm-6">
									<label> Enter Medicine Discription </label>
									<input class="form-control" value="<?php echo $dis; ?>" type="text" name="dis"  /><br/>
									</div>
									
									<div class="col-sm-6">
									<label> Enter Medicine Photo </label>
									<input type="file" value="<?php echo $p1; ?>" class="form-control" name="p1" ><br/>
									</div>

									<div class="col-sm-6">
									<label> Enter Medicine Photo2 </label>
									<input type="file" value="<?php echo $p2; ?>"   class="form-control" name="p2" ><br/>
									</div>

									<div class="col-sm-6">
									<label> Enter Medicine Photo3 </label>
									<input type="file" value="<?php echo $p3; ?>" class="form-control" name="p3" ><br/>
									</div>

									<div class="col-sm-6">
									<label> Enter Medicine Price </label>
									<input class="form-control" value="<?php echo $price; ?>" type="text" name="price"  /><br/>
									</div>

									<div class="col-sm-6">
									<label> Enter Medicine Quentity </label>
									<input class="form-control" value="<?php echo $quentity; ?>" type="text" name="quentity"  /><br/>
									</div>
							</div>
									
									
									<input type="submit" name="update" class="btn btn-success" value="Uddate NOW">
									<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
									
									
									
									
									
									
									</form>
								
								</div>
								


								<?php 
							
								
						}		
												if(isset($_POST["update"]))
												{
													$name=$_POST["name"];
													$disease=$_POST["disease"];
													$dis=$_POST["dis"];
													$price=$_POST["price"];
													$quentity=$_POST["quentity"];
													
													
													$p1=$_FILES["p1"] ["name"];
																
																//this variable is used for folder image
																$tmp=$_FILES["p1"]["tmp_name"];
																
																//move your photo into your folder
																$s=move_uploaded_file($tmp,"image/$p1");
																
																
																
													$p2=$_FILES["p2"] ["name"];
																
																//this variable is used for folder image
																$tmp2=$_FILES["p2"]["tmp_name"];
																
																//move your photo into your folder
																$s2=move_uploaded_file($tmp2,"image/$p2");
																
																
																
													$p3=$_FILES["p3"] ["name"];
																
																//this variable is used for folder image
																$tmp3=$_FILES["p3"]["tmp_name"];
																
																//move your photo into your folder
																$s3=move_uploaded_file($tmp3,"image/$p3");
																
																
																
														$update=" update medicine set name='$name',disease='$disease',dis='$dis',p1='$p1',p2='$p2',p3='$p3',price='$price',quentity='$quentity',regtime=NOW() where id='$b'";
														
														$query=mysqli_query($con,$update)or die(mysql_error());
														
														if($query)
														{
															echo "<script> alert('Medicine Uddate Successfully');</script>";
															echo "<script> window.location.href='admin.php?id=2'; </script>";
														}
													
	
													}
					
					
						
				
					
					
					
					?>

	</div>

</div>