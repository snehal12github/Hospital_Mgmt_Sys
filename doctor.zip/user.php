
<div class="container-fluid">
	<div class="row">
	<div class="col-sm-2">
		
			
		 
			<br/><br/>
		  <form>
				<a href="admin.php?id=1"  style="color:green"><button type="button" class="btn btn-outline-primary form-control"><i class="fa fa-dashboard"></i> Dashboard</button></a>
			  <br /><br />
			  <a href="admin.php?id=2"  style="color:green" ><button type="button"  class="btn btn-outline-primary form-control"><i class="fa fa-edit"></i>My Orders </button></a>
			  <br /><br />
			  
			   <a href="admin.php?id=3"  style="color:green" ><button type="button"  class="btn btn-outline-primary form-control"><i class="fa fa-edit"></i> My Appoitment </button></a>
			   
			    <br /><br />
			 
			  
			  <a href="admin.php?id=5"  style="color:green"><button type="button"  class="btn btn-outline-primary form-control"><i class="fa fa-envelope"></i> Chat </button></a>
			 
			  <br /><br />
			  
			  
				<a href="logout.php" style="color:green"><button type="button" class="btn btn-outline-primary form-control"><i class="fa fa-power-off"></i> Log Out</button></a>
			  </form>
	

	</div>

	<div class="col-sm-10">
		<br/><br/>
		<?php
		$u=$_SESSION["username"];
		$select5="select * from user where username='$u'";
			$query5=mysqli_query($con,$select5);
			while($s5=mysqli_fetch_array($query5))
			{
			   
				 $id=$s5["id"];

			}
		
		$select="select * from buyed where buyer='$u'";
		$query=mysqli_query($con,$select);
		$count=mysqli_num_rows($query);
		

		$select2="select * from book_appoitment where patient_id='$u'";
		$query2=mysqli_query($con,$select2);
		$count2=mysqli_num_rows($query2);

		$select3="select DISTINCT msg_to from chat where msg_from='$u'";
		$query3=mysqli_query($con,$select3);
		$count4=mysqli_num_rows($query3);	
	
		




		@$a=$_GET["id"];
					
					if($a==1 OR $a=="")
					{
					
					echo "
					
					
					
						
				<div class='container-fluid'>
					<div class='row'>
					<br/> <br> <br> <br> <br> <br> 
						<div style='width:200px;height:220px; background-color:#F5F5F5;margin-left:15px' class=' col-sm-2'>
							<a style='text-decoration:none;' href='admin.php?id=2'>
							<center><img src='img/order.png' class='img-rounded' width='130px' height='100px' / style='margin-top:10px'></center>


							
							
							<h3 style='text-align:center;color:black;font-size:24px; margin-top:10px'> My Orders</h3>
							
							<h3 style='text-align:center;font-size:30px'> $count </h3>
						</div> </a>


						<div style='width:200px;height:220px; background-color:#F5F5F5;margin-left:15px' class=' col-sm-2'>
							<a style='text-decoration:none;' href='admin.php?id=3'>
							<center><img src='img/app.jpg' class='img-rounded' width='130px' height='100px' / style='margin-top:10px'></center>


							
							
							<h3 style='text-align:center;color:black;font-size:24px; margin-top:10px'> Appoitment</h3>
							
							<h3 style='text-align:center;font-size:30px'> $count2 </h3>
						</div> </a>


						<div style='width:200px;height:220px; background-color:#F5F5F5;margin-left:15px' class=' col-sm-2'>
							<a style='text-decoration:none;' href='admin.php?id=5'>
							<center><img src='img/chat.png' class='img-rounded' width='130px' height='100px' / style='margin-top:10px'></center>


							
							
							<h3 style='text-align:center;color:black;font-size:24px; margin-top:10px'> My Chat</h3>
							
							<h3 style='text-align:center;font-size:30px'> $count4 </h3>
						</div> </a>



						
						
					</div>
					</div>
					
					";
					}
					
					
					
					
					
					if($a==2)
					{
						include ("myorder.php");
					}
					else if($a==3)
					{
						include("user_appoitment.php");
					}
					
					
					
					else if($a==4)
					{
						include("edit.php");
					}
					
					
					else if($a==5)
					{
						
						include("message.php");
						
					}
					
					
					?>

	</div>

</div>