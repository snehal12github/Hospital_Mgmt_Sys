<?php
include("navbar.php");
$id=$_GET["mid"];
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<br><br><br>
	<div class="container">
		<div class="row">
			<div class="col-sm-2">
				<?php
					$select="select * from medicine where id='$id'";
					$query=mysqli_query($con,$select);
					while ($a=mysqli_fetch_array($query))
					 {
					 	$name=$a["name"];
					 	$disease=$a["disease"];
					 	$dis=$a["dis"];
					 	$price=$a["price"];
					 	$quantity=$a["quentity"];
						 $img1=$a["p1"];
						  $img2=$a["p2"];
						 $img3=$a["p3"];
						 echo "
						 	<div class='col-sm-12'>
						 		<img src='medicine/$img1' width='100%' height='130px'>
						 	</div>
						 	<div class='col-sm-12'>
						 		<img src='medicine/$img2' width='100%' height='130px'>
						 	</div>
						 	<div class='col-sm-12'>
						 		<img src='medicine/$img3' width='100%' height='130px'>
						 	</div>
						 ";
					 }
				?>
			</div>
			

			<div class="col-sm-4">
				<?php
				echo "<img src='medicine/$img1' width='100%' height='300px'>";
				?>

				<form action="" method="post">
					<div class="row">
				
							<div class="col-sm-6">
								<button name="cart" class="btn btn-danger form-control">Add To Cart</button> 
							</div>

							<div class="col-sm-6">
								<button name='buy' class='btn btn-success form-control'>Buy Now</button>	
							</div>
							
					</div>
				</form>
			</div>

			<div class="col-sm-6">
				<br>
				<h2><?php echo $name; ?></h2>
					<h2><span style="font-size: 20px;">Product Used In :  </span><?php echo $disease; ?></h2>
					<h2><span style="font-size: 20px;">Product Information :  <br></span><?php echo $dis; ?></h2>
					<h2><span style="font-size: 20px;">Product Price :  </span><?php echo $price."/- Rs"; ?></h2>
			</div>



			
		</div>
	</div>
<br>
</div>
<h2 style="text-align: center;">Also Similar Medicines</h2>
<hr>
<div class="container-fluid">
	<div class="row">

		<?php
			
			
			$select="select * from medicine ORDER BY RAND() LIMIT 8;";
				$run=mysqli_query($con,$select);
				
				while($row=mysqli_fetch_array($run))
				{
					$id=$row["id"];
					$productname=$row["name"];
					$die=$row["disease"];
					$dis=$row["dis"];
					$price=$row["price"];
					$regtime=$row["regtime"];
					$img=$row["p1"];

					echo "
					
						<div class='col-sm-3'>
						<a style='text-decoration:none;' href='detail.php?mid=$id'>
							<div class='col-sm-12'>
								<img src='medicine/$img' width='100%'' height='250px'> 
							</div>
							<div class='col-sm-12'>
								<h2 style='text-align:center;'> $productname </h2>
							</div>
						</a>		
						</div>
					
						";
				}
				?>
	</div>

</div>

<br>
<?php
include("footer.php");
?>
</body>
</html>


<?php
if(isset($_POST["cart"]))
{
	 $buyer=$_SESSION["username"];

	$select2="select * from cart where p_id='$id' AND buyer='$buyer'";
	$query2=mysqli_query($con,$select2);
	echo $a=mysqli_num_rows($query2);

	if($a==0)
	{
		if($buyer=="")
			{
					echo "<script > alert('Login First');</script>";
					echo "<script> window.location.href='detail.php?mid=$id'; </script>";

			}
			else
			{
				$insert="insert into cart(p_id,buyer,date) values('$id','$buyer',Now())";
				$query=mysqli_query($con,$insert);
				if($query)
				{
					echo "<script > alert('Added To Cart');</script>";
					echo "<script> window.location.href='cart.php'; </script>";
				}

			}
				
	}
	else	
	{
		echo "<script > alert('Allready Added To Cart');</script>";
	}


		

	
}



if(isset($_POST["buy"]))
{
	 $buyer=$_SESSION["username"];

	$select2="select * from cart where p_id='$id' AND buyer='$buyer'";
	$query2=mysqli_query($con,$select2);
	echo $a=mysqli_num_rows($query2);

	if($a==0)
	{
		if($buyer=="")
			{
					echo "<script > alert('Login First');</script>";
					echo "<script> window.location.href='detail.php?mid=$id'; </script>";

			}
			else
			{
				$insert="insert into cart(p_id,buyer,date) values('$id','$buyer',Now())";
				$query=mysqli_query($con,$insert);
				if($query)
				{
					
					echo "<script> window.location.href='buy.php?mid=$id'; </script>";
				}

			}
				
	}
	else	
	{
		echo "<script > alert('Allready Added To Cart');</script>";
	}


		

	
}

?>
