<?php
include("navbar.php");
$id=$_GET["mid"];
$user=$_SESSION["username"];
if($user=="")
{
	echo "<script > alert('Login First');</script>";
	echo "<script> window.location.href='detail.php?mid=$id'; </script>";
}


$select="select * from medicine where id='$id'";
					$query=mysqli_query($con,$select);
					while ($a=mysqli_fetch_array($query))
					 {
					 	$name=$a["name"];
					 	$disease=$a["disease"];
					 	$dis=$a["dis"];
					 	$price=$a["price"];
					 	$quantity=$a["quentity"];
						 $img1=$a["p1"];
						  $img2=$a["p2"];
						 $img3=$a["p3"];
						 $fprice=$price;
						 $seller=$a["seller"];
						 
					 }
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<script>
function myFunction() {
	var x= document.getElementById("quantity").value;
 
  var y=<?php echo $price; ?>;
    var z=x*y;

     document.getElementById("myText").value =+z;
}
</script>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-4">
				
				    	<img src="img/dilivary.jpg" width="100%" height="550px">
				    
			</div>

			<div class="col-sm-4">
				<div class="card bg-default">
				    <div class="card-body"> 
				    	<form action="" method="Post"> 
				    		<label style="font-size: 25px;">Medicine Name : <?php echo $name."<br>"; ?></label>
				    			<br>
				    				<img src="medicine/<?php echo $img1; ?>" width="400px" height="150px">
				    			<br>
				    		<label style="font-size: 25px;">Medicine Used In : <?php echo $disease; ?></label>
				    			<br><br>
				    		<label style="font-size: 25px;">Discription : <?php echo $dis; ?></label>
				    			<br><br>
				    		<label style="font-size: 25px;">Medicine Price  : <?php echo $price; ?></label>
				    			<br><br>
				    		<input id="quantity" onkeyup="myFunction()" class="form-control" type="text" name="quantity" placeholder="Enter Quantity" required>
				    			<br>
				    		<input id="myText" class="form-control" type="text" name="fprice"  disabled>
				    			<br>
				    			<button name="buy" class="btn btn-success form-control">Buy Now</button>
				    		
				    	</form>
				    </div>
				</div>
			</div>

			<div class="col-sm-4">

			</div>
		</div>
	</div>
	<br><br>
	<?php
include("footer.php");
	?>
</body>
</html>

<?php
	if(isset($_POST["buy"]))
	{	
	
		 $id=$_GET["mid"];
		
		$quantity=$_POST["quantity"];
		$buyer=$_SESSION["username"];

		$update="update cart set  quantity='$quantity',price='$price' where buyer='$buyer' AND p_id='$id'" ;
		$query=mysqli_query($con,$update);
		if($query)
		{
			
			echo "<script> window.location.href='pay.php?mid=$id'; </script>";
			
		}
	}
?>