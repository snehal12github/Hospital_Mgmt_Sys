<?php
include("navbar.php");
$user=$_SESSION["username"];
if($user=="")
{
	echo "<script> alert('Login First'); </script>";
		echo "<script> window.location.href='doctors.php'; </script>";
}

 $name=$_GET["id"];
$select="select * from user where username='$name'";
 $query=mysqli_query($con,$select);
 while($a=mysqli_fetch_array($query))
 {
 	 $user_type=$a["user_type"];
 	 $email=$a["email"];
 	  $dname=$a["name"];
 	 $pass=$a["password"];
 	 $dtype=$a["type_doctor"];
 	 $price=$a["price"];
 	  $dname=$a["name"];
 	  $address=$a["address"];
 	  $photo=$a["image"];
 	   $hospital=$a["hospital"];
 }


?>
<div class="container-fluid">
	<div class="row">
		
			<div class="col-sm-3">
			</div>
			<div class="col-sm-3">
				<br><br>
				<h3>Book Appoitment</h3>
				<form action=" " method="post">
					<br>
					<label>Enter Patient Name</label>
					<input type="text" class="form-control" name="name" required>
					<br>
					<label>Enter Patient Mobile No</label>
					<input type="text" class="form-control" name="number" required>
					<br>
					<label>Book date</label>
					<input type="date" class="form-control" name="date" required>
					<br>
					<label>Book Time</label>
							<div class="row">
								<div class="col-sm-6">
									<input type="text" class="form-control" name="time">
								</div>
								<div class="col-sm-6">
									<select class="form-control" name="am">
										<option>AM</option>
										<option>PM</option>
									</select>
										
								</div>

								

							</div>
							<br>
					<input type="submit" class="form-control btn btn-success" name="book" value="Book Now">
					
				</form>
			</div>

			<div class="col-sm-1">
				
			</div>

			<div class="col-sm-3">
				<br><br>
				<?php
					echo "	<img src='image/$photo' class='rounded' width='100%' height='250px;''>
						<br>
						<h4 style='margin-top:30px;'>Doctor Name : $dname</h4><br>
						<h4>Specility : $dtype</h4><br>
						<h4>hospital : $hospital</h4><br>
						<h4>Address  : $address</h4>
						";
				?>

			</div>
		</div>
	
</div>


<?php
	if(isset($_POST["book"]))
	{
		$pname=$_POST["name"];
		$number=$_POST["number"];
		$date=$_POST["date"];
		$time=$_POST["time"];
		$am=$_POST["am"];
		$patient_id=$_SESSION["username"];

		$insert="insert into book_appoitment(doctor,patient_id,patient,p_mobile,book_date,time_from,am,date)
		 values('$name','$patient_id','$pname','$number','$date','$time','$am',NOW())";
		 $query=mysqli_query($con,$insert);

		 if($query)
	{
		echo "<script> alert('Appointment Book Succesfully'); </script>";
		

		echo "<script> window.location.href='admin.php?id=3'; </script>";
	}

	}
echo "<br><br>";
	include("footer.php");
?>