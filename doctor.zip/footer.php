<div class="container-fluid">
	<div style="padding: 20px;background-color: black;" class="row">
		
			<div class="col-sm-9">
				<p style="color: white;"><span style="font-size: 20px;color: green"> Medi</span>Care  Copyright © 2021, Practo. All rights reserved. </p>
			</div>

			<div class="col-sm-3">
						<a href="" data-toggle="tooltip" data-placement="top" title="Lets Connect With Facebook!"> <img src="img/facebook.png" width="60px" height="50px"> </a>

					<a href="" data-toggle="tooltip" data-placement="top" title="Lets Connect With Twitter!"> <img  src="img/twitter (1).png" width="40px" height="40px"> </a>

					<a href="" data-toggle="tooltip" data-placement="top" title="Lets Connect With Instagram!"> <img style="margin-left: 5px;" src="img/insta.png" width="50px" height="50px"> </a>

					<a href="" data-toggle="tooltip" data-placement="top" title="Lets Connect With WhatsApp!"> <img  src="img/wh2.png" width="60px" height="60px"> </a>
			</div>
			
		
	</div>
</div>