<?php
$con=mysqli_connect("localhost","root","","doctor");

session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>MediCare</title>
	<link rel="stylesheet" type="text/css" href="link/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="link/navbarstyle.css">
	<script src="link/bootstrap.js"></script>
	<script src="link/ajax.js"></script>
	<script src="link/jquery.js"></script>

<!-- Online Links For Bootstrap  -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</head>
<body>
<?php
@$name=$_SESSION["username"];
if($name=="")
{
	echo '

	<nav style="padding: 40px;height: 80px" class="navbar navbar-expand-md bg-white fixed-top">
		  <a class="navbar-brand" href="index.php"><img src="img/d1.png" width="100px" height="40px;"></a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		    <ul class="navbar-nav">
		    	<div class="col-sm-1">
		    		
		    	</div>
		    	<div class="col-sm-3">
		    		 <li class="nav-item">
				       	  <a class="nav-link" href="doctors.php"><h6>Doctors <span><br> Book An Appointment</span></h6></a>
		      			  <p></p>
				      </li>
		    	</div>
		     
		    	<div class="col-sm-3">
				      <li class="nav-item">
				        <a class="nav-link" href="consult.php"><h6>Consult  <span><br> Consult With Top Doctors</span> </h6></a>
				      </li>
				</div>

			     <div class="col-sm-3">
			    		 <li class="nav-item">
					       	  <a class="nav-link" href="pharmacy.php"><h6>Pharmacy <span><br> Medicine & Products</span></h6></a>
					      </li>
			     </div>

			    


				<div class="col-sm-9">
				</div>


				 <div class="col-sm-3">
				      <li class="nav-item">
				      	<br>

				      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
								   Login/SignUp
						  </button>
				    
				</li>
				</div>


		    </ul>
		  </div>  
		</nav>

	';

}

else

{
	echo '
		<nav style="padding: 40px;height: 80px" class="navbar navbar-expand-md bg-white fixed-top">
		  <a class="navbar-brand" href="index.php"><img src="img/d1.png" width="100px" height="40px;"></a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		    <ul class="navbar-nav">
		    	<div class="col-sm-1">
		    		
		    	</div>
		    	<div class="col-sm-3">
		    		 <li class="nav-item">
				       	  <a class="nav-link" href="doctors.php"><h6>Doctors <span><br> Book An Appointment</span></h6></a>
		      			  <p></p>
				      </li>
		    	</div>
		     
		    	<div class="col-sm-3">
				      <li class="nav-item">
				        <a class="nav-link" href="consult.php"><h6>Consult  <span><br> Consult With Top Doctors</span> </h6></a>
				      </li>
				</div>

			     <div class="col-sm-3">
			    		 <li class="nav-item">
					       	  <a class="nav-link" href="pharmacy.php"><h6>Pharmacy <span><br> Medicine & Products</span></h6></a>
					      </li>
			     </div>

			   

				<div class="col-sm-3">
				      <li class="nav-item">
				        <a class="nav-link" href="admin.php"><h6> Control Area <span><br> Admin Area</span> </h6></a>
				      </li>
				</div>


				<div class="col-sm-2">

				</div>
				<div class="col-sm-2">
						<li class="nav-item">
				        <a class="nav-link" href="cart.php"><h6> <br>My Cart</h6></a>
				      </li>
				</div>


				 <div class="col-sm-3">
				      <li class="nav-item">
				      	<br>

				     <a href="logout.php"> <button class="btn btn-danger"> Logout </button> </a>
				    
				</li>
				</div>


		    </ul>
		  </div>  
		</nav>

';
}
?>
		
	</body>
<br><br><br><br>









<!-- Login/Sign Up -->

<div class="container">
  
  
  
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
        	 <h4 class="modal-title">Login/SignUp Here</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         
        </div>
        <div class="modal-body">
         
        	<form action="" method="post">
        	
        		<input type="text" name="name" class="form-control" placeholder="Enter Username">
        			<br> <br>
        		
        		<input type="Password" name="Password" class="form-control" placeholder="Enter Password">
        			<br> <br>

        		<input type="submit" class="btn btn-success form-control" value="Login" name="save">

        	</form>


        </div>
        <div class="modal-footer">
        	<button type="button" class="btn btn-info " data-toggle="modal" data-target="#myModal2" >Sign Up</button>

          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>




<!-- Sign Up-->



<div id="myModal2" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
      	 <h4 class="modal-title">Sign Up</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
       
      </div>
      <div class="modal-body">
         	<form name="myForm" action="" method="post" onkeyup ="return verifyPassword()">
        	
        		<input type="text" name="name" class="form-control" placeholder="Enter Username" required>
        			<br> <br>
        		
        		<input type="email" name="email" class="form-control" placeholder="Enter Email">
        			<br> <br>


        		<input id="pass" type="Password" name="Password" class="form-control" placeholder="Enter Password">
        			<br> 
        			<span id = "message2" style="color:red"> </span>  <br> 
        			<br>
        		<input id="pass2" type="Password" name="cPassword" class="form-control" placeholder="Confirm Password">
        			<br>
								<span id = "message" style="color:red"> </span> <br> 


        		<label> Select Type Of User</label>
        		<select class="form-control" name="user">
        			<option value="User">
        				User
        			</option>
        			<option value="doctor">
        				Doctor
        			</option>
        			<option value="medical">
        				Medical
        			</option>
        		</select>
        		
        			<br> <br>


        		<input type="submit" class="btn btn-success form-control" value="Register" name="Register">

        	</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>



<?php
if(isset($_POST["save"]))
{
	 $name=$_POST["name"];
	$pass=$_POST["Password"];
	
 

	$select="select * from user where username='$name'";
	$query=mysqli_query($con,$select);


		while($row=mysqli_fetch_array($query))
				{
					  $pass2=$row["password"];
				}


	
	if($pass==$pass2)
	{
		echo "<script> alert('Loged In Successfully'); </script>";
		@session_start();
		$_SESSION["username"]=$name;
		echo "<script> window.location.href='admin.php'; </script>";
		
	}
	else
	{
		echo "<script> alert('Invalid Details'); </script>";
	}
	




	
	

}

?>








<?php


if(isset($_POST["Register"]))
{
	@$id=$_POST["id"];
	$name=$_POST["name"];
	$email=$_POST["email"];
	$password=$_POST["Password"];
	$cpass=$_POST["cPassword"];
	$user=$_POST["user"];
	//$hashed_password = password_hash($password, PASSWORD_DEFAULT);


	$select2="select * from user where username='$name'";
	$q2=mysqli_query($con,$select2);
	$a2=mysqli_num_rows($q2);

	if($a2==1)
	{
		echo "<script> alert('Username Already Registered '); </script>";
	}

	$select3="select * from user where email='$email'";
	$q3=mysqli_query($con,$select3);
	$a3=mysqli_num_rows($q3);

	if($a3==1)
	{
		echo "<script> alert('Email Already Registered '); </script>";
	}
	
	else
	{
				$insert="insert into user(username,email,password,user_type,date) values('$name','$email','$password','$user',NOW())";
			$query=mysqli_query($con,$insert);

			if($query)
			{
				echo "<script> alert('Registered Succesfully'); </script>";
				@session_start();
				$_SESSION["username"]=$name;

				echo "<script> window.location.href='admin.php'; </script>";
			}
	}



	


}

?>