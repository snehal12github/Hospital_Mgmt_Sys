<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<table class="table table-striped">
				<tr>
					<th>Product_id</th>
					<th>Product Name</th>
					<th>Product Image</th>
					<th>Product Used For</th>
					<th>Total Price</th>
					<th>Address</th>
					<th>Buyer</th>
					<th>Mobile No</th>
					<th>Date</th>
				</tr>
				<?php
					    $uname=$_SESSION["username"];
						$select="select * from buyed where seller='$uname'";
						$query=mysqli_query($con,$select);
						while($a=mysqli_fetch_array($query))
						{
							$pid=$a["p_id"];
							$date=$a["time"];
							$quantity=$a["quantity"];
							$address=$a["address"];
							$buyer=$a["buyer"];
							$mobile=$a["mobile"];
							
							
									$select2="select * from medicine where id='$pid'";
									$query2=mysqli_query($con,$select2);
									while($a2=mysqli_fetch_array($query2))
										{
											$mname=$a2["name"];
											$disease=$a2["disease"];
											$photo=$a2["p1"];
											$price=$a2["price"];
											$total=$quantity*$price;



							echo "
							<tr>
								<td>$pid</td>
								<td>$mname</td>
								<td> <img src='medicine/$photo' width='100px' height='100px'> </td>
								<td>$disease</td>
								<td>$total</td>
								<td>$address</td>
								<td>$buyer</td>
								<td>$mobile</td>
								<td>$date</td>
								

							</tr>";
						}
					}
					?>
			</table>
		</div>
	</div>
</body>
</html>