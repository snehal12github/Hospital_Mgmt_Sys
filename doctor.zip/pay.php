<?php
include("navbar.php");
$id=$_GET["mid"];
$user=$_SESSION["username"];
if($user=="")
{
	echo "<script > alert('Login First');</script>";
	echo "<script> window.location.href='index.php'; </script>";
}
?>

<?php
	$select2="select * from cart where p_id='$id' AND buyer='$user'";
	$query2=mysqli_query($con,$select2);
	while ($a=mysqli_fetch_array($query2))
	 {
		$price=$a["price"];
		$quantity=$a["quantity"];
		$total=$price*$quantity;
		
		
		$se3="select * from medicine where id='$id'";
		$query3=mysqli_query($con,$se3);
			while ($a3=mysqli_fetch_array($query3))
			 {
				 $seller=$a3["seller"];
			 }
	}
 echo "
		
		 <br/>
				<div style='width:60%' class='container card' >
					<div class='row'>
						<div class='col-sm-1'>
							
						</div>
						
						<div class='col-sm-6 card-body'>
							<form action='' method='post'>
								<div class='form-group'>
									<label>Select Your Bank</label>
									<select class='form-control'>
										<option>Select your bank</option>
										<option>State Bank Of Maharastra</option>
										<option>Bank Of India</option>
										<option>State Bank Of India</option>
										<option>Union Bank</option>
									</select>
								</div>
								<div class='form-group'>
									<label>Username</label>
									<input type='text' placeholder='Username' class='form-control' required />
								</div>
								
								<div class='form-group'>
									<label>Money</label>
									<input type='text' placeholder='$total' class='form-control' disabled />
								</div>
								
								<div class='form-group'>
									<label>Password</label>
									<input type='password' placeholder='*********' class='form-control' required />
								</div>
								<div class='form-group'>
									<label>CVV</label>
									<input type='password' placeholder='CVV' class='form-control' required />
								</div>
								
								<input type='submit' name='paynow' value='Pay Now' class='btn btn-success' />
							
							
							<br/>
							<br/>
					</div>

					<div class='col-sm-4'>
						<div class='form-group'>
						<br>
							<label>Address</label>
							<textarea name='address' class='form-control' required>

							</textarea>
						</div>

						<div class='form-group'>
									<label>Enter Mobile Number</label>
									<input name='mobile' type='text' placeholder='Mobile Number' class='form-control' required />
						</div>


					</div>

				</div>
				</form>
		 
		 ";

?>


<?php
if(isset($_POST["paynow"]))	
	{
		$address=$_POST["address"];
		$mobile=$_POST["mobile"];
			
			$insert="insert into buyed(p_id,quantity,total,buyer,address,mobile,time,seller) values('$id','$quantity','$total','$user','$address','$mobile',NOW(),'$seller')";
			$run=mysqli_query($con,$insert);
			if($run)
					{
						$delet="delete  from cart where p_id='$id' AND buyer='$user'";
						$go=mysqli_query($con,$delet) or die(mysql_error());
						echo "<script> alert('your Order Registered '); </script>";
						echo "<script> window.location.href='admin.php?id=2'; </script>";
					
					}


		}	

?>