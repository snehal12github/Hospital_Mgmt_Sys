<?php
include("navbar.php");
 $doctor=$_GET["id"];
?>
<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<h4 style="text-align: center;"> Top Doctors</h4>
				<hr>

				<?php
					$select="select * from user where type_doctor='$doctor'";
					 $query=mysqli_query($con,$select);
					  $num=mysqli_num_rows($query);
					if($num==0)
					 	  {
					 	  	echo "<script> alert('Doctors Are Not Avalablel');</script>";
					 	  	echo "<script>window.location.href='doctors.php'; </script>";
					 	  }
					 while($a=mysqli_fetch_array($query))
					 {
					 	$dname=$a["name"];
					 	 $uname=$a["username"];
					 	 $email=$a["email"];
					 	 $pass=$a["password"];
					 	 $dtype=$a["type_doctor"];
					 	 $img=$a["image"];
					 	  $hospital=$a["hospital"];
					 	  $address=$a["address"];
					 	  
					 

					 echo "

					 	<div style='padding:20px;' class='col-sm-4'>
					 		<div class='container-fluid'>
							    <div class='row'>
							        <div style='background-image: linear-gradient(#00c9ff, #92FE9D);height: 50px;' class='col-sm-12'>
							            <h4 style='color: white;text-align: center;''>$hospital</h4>
							        </div>
							       
							              <div class='col-sm-4'>
							                <img style='margin-top: 0px;'' class='rounded-circle' src='image/$img' height='150px' width='140px'>
							              </div>

							              <div class='col-sm-8'>
							              <br>
							                <h6>Name : $dname</h6> <br>
							                <h6> Expert In : $dtype </h6> <br>
							                <h6> Address  : $address </h6> <br>
							                
							              </div>
							              <div class='col-sm-12'>
							              <a href='book.php?id=$uname'><button class='btn btn-success form-control'> Book Appointmemt </button> </a>
							              </div>
							         
							    </div>
							    </div> 
					 	</div>
					 ";
					}
				?>

				
			</div>
			
		</div>
	</div>
	<br><br>