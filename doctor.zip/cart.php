<?php
include("navbar.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<br> <br> <br>
	<div class="container">
		<div class="row">
			<table class="table table-striped">
				<tr>
					<th>Product_id</th>
					<th>Product Name</th>
					<th>Product Image</th>
					<th>Product Used For</th>
					<th>Buy Now</th>
					
					
					<th>Delete</th>
				</tr>
				<?php
					 $uname=$_SESSION["username"];
						$select="select * from cart where buyer='$uname'";
						$query=mysqli_query($con,$select);
						while($a=mysqli_fetch_array($query))
						{
							$pid=$a["p_id"];
							
							$quantity=$a["quantity"];
							
							
							
									$select2="select * from medicine where id='$pid'";
									$query2=mysqli_query($con,$select2);
									while($a2=mysqli_fetch_array($query2))
										{
											$mname=$a2["name"];
											$disease=$a2["disease"];
											$photo=$a2["p1"];
											$price=$a2["price"];
											$total=$quantity*$price;



							echo "
							<tr>
								<td>$pid</td>
								<td>$mname</td>
								<td> <img src='medicine/$photo' width='100px' height='100px'> </td>
								<td>$disease</td>
								<td><a style='color:green' href='buy.php?mid=$pid'>  Buy Now </a></td>
								
								
								<td><a style='color:red' href='delete.php?id=$pid'>  Delete </a></td>
								

							</tr>";
						}
					}
					?>
			</table>
		</div>
	</div>
</body>
</html>