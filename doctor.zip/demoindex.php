<?php
include("navbar.php");
?>
<!DOCTYPE html>
<html>
<head>
  <title> Home Page</title>
  <link rel="stylesheet" type="text/css" href="link/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="link/style.css">
  <script src="link/bootstrap.js"></script>
  <script src="link/ajax.js"></script>
  <script src="link/jquery.js"></script>
</head>
<body>


<div class="container-fluid">
    <div class="row">
        <div style="background-image: linear-gradient(#00c9ff, #92FE9D);height: 50px;" class="col-sm-12">
            <h4 style="color: white;text-align: center;">$hospital</h4>
        </div>
       
              <div class="col-sm-2">
                <img style="margin-top: -40px;" class="rounded-circle" src="img/d1.jpg" height="200px;" width="200px">
              </div>

              <div class="col-sm-3">
                <h4>Name : $dname</h4>
                <h4> Expert In : $dtype </h4>
                <a href='book.php?id=$uname'><button class='btn btn-success'> Book Appointmemt </button> </a>
              </div>
         
    </div>
    </div> 
 
</body>
</html>