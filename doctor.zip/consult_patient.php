
<?php

	$name=$_SESSION["username"];
	$select="select * from chat where  msg_to='$name'";
	$query=mysqli_query($con,$select);
	while ($a=mysqli_fetch_array($query)) 

	{
		 $name2=$a['msg_from'];
		 
				 $select="select * from user where  username='$name2'";
				$query=mysqli_query($con,$select);
				while ($a=mysqli_fetch_array($query)) 

				{
					 $cid=$a['id'];
					  $img=$a['image'];
					 $username=$a['username'];
				}
		
		 echo "
		
		<a href='chat2.php?cid=$username' style='color:black'>
			 <div class='container-fluid'>
				<div class='row'>
					<div style='height:70px;border:1px solid;margin-top:10px;' class='col-sm-5'>
							<div style='margin-top:10px;' class='row'>
								<div class='col-sm-2'>
									<img class='rounded-circle' src='image/$img' width='50px' height='50px'>
								</div>
								<div class='col-sm-6'>
									 $username 
								</div>
							</div>
		 					 

						<br> 
					</div>
		

			</div>
			
		</div>
		</a>
		 ";
	}


?>
