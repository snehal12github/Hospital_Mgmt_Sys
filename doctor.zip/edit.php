<?php
 $name=$_SESSION["username"];
 $select="select * from user where username='$name'";
 $query=mysqli_query($con,$select);
 while($a=mysqli_fetch_array($query))
 {
 	 $user_type=$a["user_type"];
 	 $email=$a["email"];
 	 $pass=$a["password"];
 	 $dtype=$a["type_doctor"];
 	 $price=$a["price"];
 	  $dname=$a["name"];
 	  $address=$a["address"];
 	  $photo=$a["image"];
 	   $hospital=$a["hospital"];
 	   $mobile=$a["mobile"];
 }
?>



<div class="container-fluid">
	<div class="row">
		<div class="col-sm-5">
		<h4>Edit Profile</h4> 
		<form action="" method="post" enctype="multipart/form-data">
		<br>
			<label>Name</label>
			<input type="text" class="form-control" name="name" value="<?php echo $dname;  ?>">
			<br>
			<label>Username</label>
			<input type="text" class="form-control" name="username" value="<?php echo $name;  ?>">
			<br>
			<label>Email</label>
			<input type="text" class="form-control" name="email" value="<?php echo $email;  ?>">
			<br>
			<label>Type Of Doctor</label>
			<select name="type" class="form-control">
				<?php
					if($dtype!="")
					{
						echo "<option value='$dtype'>$dtype </option>";
					}
				?>
				<option value="gynaecologist">Gynaecologist </option>
				<option value="genral">Genral </option>
				<option value="dermatology">Dermatology </option>
				<option value="cardiologist">Cardiologist </option>
				<option value="dentist">Dentist </option>
				<option value="childern">Children care </option>
				<option value="dermatology">Dermatology </option>
				<option value="cardiology">Cardiology </option>
				<option value="neurologists">Neurologists </option>
				<option value="otolaryngology">Otolaryngology </option>
			</select>
			<br> 
			<label>Consaltancy Price/hour</label>
			<input type="text" class="form-control" name="price" value="<?php echo $price;  ?>">
			<br>
			<label>Mobile No</label>
			<input type="text" class="form-control" name="mobile" value="<?php echo $mobile;  ?>">
			<br>

			<input type="submit" class="btn btn-success" name="update" value="Update">
		
	</div>

	<div class="col-sm-5">
		<br><br>
		<label>Address</label>
		<textarea name="address" class="form-control" >
			<?php echo $address;  ?>
		</textarea>
		<br>
		<label>Hospital Name</label>
		<input type="text" class="form-control" name="hospital" value="<?php echo $hospital;  ?>">
		<br>

		<?php
		if($photo=="")
		{
			echo '
			<img src="img/d1.jpg" class="rounded" width="80%" height="200px">
			';
		}
		else
		{
			echo "
			<img src='image/$photo' class='rounded' width='80%'' height='200px'>
			";
		}
		?>
		

		<input type="file" name="photo" class="form-control"> 
		</form>
	</div>

	</div>
</div>

<?php
if(isset($_POST["update"]))
{
	$dname=$_POST["name"];
	$docname=$_POST["username"];
	$email=$_POST["email"];
	$type=$_POST["type"];
	$price=$_POST["price"];
	$address=$_POST["address"];
	$hospital=$_POST["hospital"];
	$mobile=$_POST["mobile"];

		$img=$_FILES["photo"] ["name"];
	 //this variable is used for folder image
	$tmp=$_FILES["photo"]["tmp_name"];
																
	//move your photo into your folder
	$s=move_uploaded_file($tmp,"image/$img");

if($img=="")
{
	$update="update user set  username='$docname', email='$email', type_doctor='$type', price='$price',name='$dname',address='$address',image='$photo',hospital='$hospital',mobie='$mobile'
	where username='$name'
	" ;
	$query=mysqli_query($con,$update);
}
else
{
	$update="update user set  username='$docname', email='$email', type_doctor='$type', price='$price',name='$dname',address='$address',image='$img',hospital='$hospital',mobie='$mobile'
	where username='$name'
	" ;
	$query=mysqli_query($con,$update);
}

	
	if($query)
	{
		echo "<script> alert('Updated Sucessfully'); </script>";
		echo "<script> window.location.href='admin.php?id=4'; </script>";
	}
}
?>