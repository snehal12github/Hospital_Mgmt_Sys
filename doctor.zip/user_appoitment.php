<table class='table table-striped'>
	<tr>
		<th>Booking_ID</th>
		<th>Doctor Name</th>
		<th>Doctor Image</th>
		<th>Hosptal Name</th>
		<th>Patient Name</th>
		<th>Date</th>
		<th>Time</th>

	</tr>

	<?php
	 $uname=$_SESSION["username"];
		$select="select * from book_appoitment where patient_id='$uname'";
		$query=mysqli_query($con,$select);
		while($a=mysqli_fetch_array($query))
		{
			$bid=$a["id"];
			$doctor=$a["doctor"];
			$patient=$a["patient"];
			$mobile=$a["p_mobile"];
			$date=$a["book_date"];
			$time=$a["time_from"];
			$am=$a["am"];
					$select2="select * from user where username='$doctor'";
					$query2=mysqli_query($con,$select2);
					while($a2=mysqli_fetch_array($query2))
						{
							$dname=$a2["name"];
							$hospital=$a2["hospital"];
							$photo=$a2["image"];



			echo "
			<tr>
				<td>$bid</td>
				<td>$dname</td>
				<td> <img src='image/$photo' width='100px' height='100px'> </td>
				<td>$hospital</td>
				<td>$patient</td>
				<td>$date</td>
				<td>$time $am</td>

			</tr>";
		}
	}
		
	?>
</table>