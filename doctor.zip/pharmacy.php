<?php
include("navbar.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

</head>
<body>
<div class="container-fluid">
		<div style="background-image: url('img/mm.jpg');  background-repeat: no-repeat; height: 500px; " class="row">
				<div class="col-sm-4">
				 	
				 </div>
				  <div class="col-sm-4">
				  	<br><br><br><br><br><br><br>
				 	<h2 style="font-family: Algerian;color: white;text-align: center;">Welcome to Medicare</h2>
				 	<br>
				 	<h5 style="text-align: center;font-family: Calibri;color: white;">Find And Buy</h5>
				 	<br>
				 	<form action="" method="POST">
				 		<div class="col-sm-12">
				 			<div class="row">
				 				<div class="col-sm-10">
				 					<input type="text" class="form-control" name="search" placeholder="Find Or Search Medicines" >
				 				</div>
				 				<div style="margin-left: -30px;" class="col-sm-2">
				 					<input type="submit" class="btn btn-success" name="find" value="Search">
				 				</div>
				 			</div>
				 		</div>
				 	</form>

				 	<br><br><br>

				 </div>
				  <div class="col-sm-4">
				 	
				 </div>
		</div>
</div>
<br><br>

<h2 style="text-align: center;">Top Medicines</h2>
<hr>
<div class="container-fluid">
	<div class="row">

		<?php
			
			if(isset($_POST["find"]))
			{
				$search=$_POST["search"];
				$select="select * from medicine where name like '$search%' ";
				$run=mysqli_query($con,$select);
				
				while($row=mysqli_fetch_array($run))
				{
					$id=$row["id"];
					$productname=$row["name"];
					$die=$row["disease"];
					$dis=$row["dis"];
					$price=$row["price"];
					$regtime=$row["regtime"];
					$img=$row["p1"];

					echo "
					
						<div class='col-sm-3'>
						<a style='text-decoration:none;' href='detail.php?mid=$id'>
							<div class='col-sm-12'>
								<img src='medicine/$img' width='100%'' height='250px'> 
							</div>
							<div class='col-sm-12'>
								<h2 style='text-align:center;'> $productname </h2>
							</div>
						</a>		
						</div>
					
						";
				}
				
			}
			else
			{
			
			
			$select="select * from medicine ORDER BY RAND() LIMIT 8;";
				$run=mysqli_query($con,$select);
				
				while($row=mysqli_fetch_array($run))
				{
					$id=$row["id"];
					$productname=$row["name"];
					$die=$row["disease"];
					$dis=$row["dis"];
					$price=$row["price"];
					$regtime=$row["regtime"];
					$img=$row["p1"];

					echo "
					
						<div class='col-sm-3'>
						<a style='text-decoration:none;' href='detail.php?mid=$id'>
							<div class='col-sm-12'>
								<img src='medicine/$img' width='100%'' height='250px'> 
							</div>
							<div class='col-sm-12'>
								<h2 style='text-align:center;'> $productname </h2>
							</div>
						</a>		
						</div>
					
						";
				}
				
				}
				?>
		</div>
	</div>
</div>
<br><br>



<div class="container-fluid">
		<div class="row">
				<img src="img/cod.jpg" width="100%">
		</div>
</div>



<?php
include("footer.php");
?>
</body>
</html>