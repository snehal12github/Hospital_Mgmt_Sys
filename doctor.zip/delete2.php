<?php
include("navbar.php");
	 $d=$_GET['delete'];
@session_start();
 $user=$_SESSION['username'];
	 $delete="delete from medicine where seller='$user' AND id='$d'";
	 $query=mysqli_query($con,$delete);

	 if($query)
	 {
	 	echo "<script> alert('medicine deleted') </script>";
	 	
	 	 echo "<script> window.location.href='admin.php?id=2'; </script>";

	 }

?>