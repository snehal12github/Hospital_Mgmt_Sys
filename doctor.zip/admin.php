<?php
include("navbar.php");

 $name=$_SESSION["username"];
if($name=="")
{
	echo "<script> alert('Login First'); </script>";
	echo "<script> window.location.href='index.php'; </script>";
}

 $select="select * from user where username='$name'";
 $query=mysqli_query($con,$select);
 while($a=mysqli_fetch_array($query))
 {
 	 $user_type=$a["user_type"];
 	 $email=$a["email"];
 }

 if($user_type=="doctor")
 {
 	include("doctor.php");
 }
 elseif ($user_type=="medical")
  {
 	include("medical.php");
 }
 else
 {
 	include("user.php");
 }
?>