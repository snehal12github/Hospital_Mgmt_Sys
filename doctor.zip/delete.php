<?php
include("navbar.php");
$id=$_GET["id"];
@session_start();
$user=$_SESSION["username"];
$delet="delete  from cart where p_id='$id' AND buyer='$user'";
$go=mysqli_query($con,$delet) or die(mysql_error());
echo "<script> alert('your Cart Deleted '); </script>";
echo "<script> window.location.href='cart.php'; </script>";
?>