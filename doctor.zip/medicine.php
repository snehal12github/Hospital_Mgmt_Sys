<?php
$con=mysqli_connect("localhost","root","","doctor");
$user=$_SESSION["username"];
?>

<div class="col-sm-6">
<button type="button" class="btn btn-success btn-lg" data-toggle="modal" data-target="#myModal3"> <span style="font-size:20px">+ </span>ADD Medicine</button>
</div>
<br>

<div class="col-sm-2">
</div>
<div class="col-sm-4">
	<form method="post" action="">
		<input type="text" name="searcht" />
		<input class="btn btn-success" type="submit" value="search" name="search"/>
	
	</form>
</div>
<br/>


<!-- Modal -->
<div id="myModal3" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
      	 <h4 class="modal-title">Add Medicine</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
       
      </div>
      <div class="modal-body">
        
		<form action="" method="post" enctype="multipart/form-data">
		
		
		<label> Enter Medicine Name </label>
		<input class="form-control" type="text" name="name" required /><br/>
		
		<label> Enter Medicine for Which Disease </label>
		<input class="form-control" type="text" name="disease" required /><br/>
		
		
		<label> Enter Medicine Discription </label>
		<input class="form-control" type="text" name="dis" required /><br/>
		
		
		
		<label> Enter Medicine Photo </label>
		<input type="file" class="form-control" name="p1" required><br/>
		
		<label> Enter Medicine Photo2 </label>
		<input type="file" class="form-control" name="p2" ><br/>
		
		<label> Enter Medicine Photo3 </label>
		<input type="file" class="form-control" name="p3" ><br/>
		
		<label> Enter Medicine Price </label>
		<input class="form-control" type="text" name="price" required /><br/>
		
		<label> Enter Medicine Quentity </label>
		<input class="form-control" type="text" name="quentity" required /><br/>
		
		
		<input type="submit" name="add" class="btn btn-success" value="ADD NOW">
		<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		
		
		
		
		
		
		</form>
		<?php
		
if(isset($_POST["add"]))
{
	$name=$_POST["name"];
	$disease=$_POST["disease"];
	$dis=$_POST["dis"];
	$price=$_POST["price"];
	$quentity=$_POST["quentity"];
	$seller=$_SESSION["username"];
	
	$p1=$_FILES["p1"] ["name"];
				
				//this variable is used for folder image
				$tmp=$_FILES["p1"]["tmp_name"];
				
				//move your photo into your folder
				$s=move_uploaded_file($tmp,"medicine/$p1");
				
				
				
	$p2=$_FILES["p2"] ["name"];
				
				//this variable is used for folder image
				$tmp2=$_FILES["p2"]["tmp_name"];
				
				//move your photo into your folder
				$s2=move_uploaded_file($tmp2,"medicine/$p2");
				
				
				
	$p3=$_FILES["p3"] ["name"];
				
				//this variable is used for folder image
				$tmp3=$_FILES["p3"]["tmp_name"];
				
				//move your photo into your folder
				$s3=move_uploaded_file($tmp3,"medicine/$p3");
				
				
				
	
		$insert="insert into medicine(name,disease,dis,p1,p2,p3,price,quentity,regtime,seller) values('$name','$disease','$dis','$p1','$p2','$p3','$price','$quentity',NOW(),'$seller')";
		$query=mysqli_query($con,$insert)or die(mysql_error());
		
		if($query)
		{
			echo "<script> alert('Medicine Inserted Successfully');</script>";
			echo "<script> window.location.href='admin.php?id=2'; </script>";
		}
	
	
}


?>
  
      </div>
     
    </div>

  </div>
</div>

<?php

	if(isset($_POST["search"]))
	{
		$search=$_POST["searcht"];
		
		echo '<div class="container-fluid">
								<div class="row">
								
									<h3 style="text-align:center;font-size:30px;">  </h3>
									<br/> <br/>
									
									<div class="col-sm-12">
									<br/><br/>
										<table class="table table-hover">
							<thead>
							  <tr>
								<th>Id</th>
								<th>Name</th>
								<th>Disease</th>
								<th>Discription</th>
								<th>Image </th>
								<th>Price/piece </th>
								<th>Quentity</th>
								<th>Date OF Add </th>
								<th>EDIT </th>
								<th>delete </th>
							  </tr>
							</thead>
							<tbody>';
							
							
							
							  $select="select * from medicine where name like '$search%' or disease like '$search%' or regtime like '$search%' or regtime like '%$search' where seller='$user' ";
								$q=mysqli_query($con,$select);
								while($a=mysqli_fetch_array($q))
								{
									$id=$a["id"];
									$name=$a["name"];
									$disease=$a["disease"];
									$dis=$a["dis"];
									$p1=$a["p1"];
									$price=$a["price"];
									$qu=$a["quentity"];
									$regtime=$a["regtime"];
								
									echo "
									<tr>
									<td> $id</td>
									<td> $name</td>
									<td> $disease</td>
									<td> $dis</td>
									<td> <img src='medicine/$p1' width='100px' height='100px'/> </td>
									<td> $price</td>
									<td> $qu</td>
									
									<td> $regtime</td>
									<td> <a href='medicine_edit.php?edit=$id' > EDIT</a></td>
									
									
									
									
									</tr>
									";
								
								}
		
		
	}
	
	else
	{

						echo '
						<div class="container-fluid">
								<div class="row">
								
									<h3 style="text-align:center;font-size:30px;">  </h3>
									<br/> <br/>
									
									<div class="col-sm-12">
									<br/><br/>
										<table class="table table-hover">
							<thead>
							  <tr>
								<th>Id</th>
								<th>Name</th>
								<th>Disease</th>
								<th>Discription</th>
								<th>Image </th>
								<th>Price/piece </th>
								<th>Quentity </th>
								<th>Date OF Add </th>
								<th>EDIT </th>
								<th>delete </th>
							  </tr>
							</thead>
							<tbody>';
							
							
							
							  $select="select * from medicine where seller='$user' ";
								$q=mysqli_query($con,$select);
								while($a=mysqli_fetch_array($q))
								{
									$id=$a["id"];
									$name=$a["name"];
									$disease=$a["disease"];
									$dis=$a["dis"];
									$p1=$a["p1"];
									$price=$a["price"];
									$qu=$a["quentity"];
									$regtime=$a["regtime"];
								
									echo "
									<tr>
									<td> $id</td>
									<td> $name</td>
									<td> $disease</td>
									<td> $dis</td>
									<td> <img src='medicine/$p1' width='100px' height='100px'/> </td>
									<td> $price</td>
									<td> $qu</td>
									
									<td> $regtime</td>
									<td> <a href='medicine_edit.php?edit=$id' > EDIT</a></td>
									<td> <a style='color:red' href='delete2.php?delete=$id' > delete</a></td>
									
									
									
									</tr>
									";
								
								}
	}
								?>
								
        
     
      
    </tbody>
  </table>
  </div>
  </div>
  
  