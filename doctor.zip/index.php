<?php
	include("navbar.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Index Page</title>
	<style>
		.demo:hover{
			background-color: lightblue;
			border-radius: 20px;
		}

		.demo2:hover{
			background-color: lightgreen;
			border-radius: 20px;

		}
	</style>
</head>
<body>

</body>
</html>
<body>
	<!--  For Banner And Searchbar -->

	<div class="container-fluid">
		<div style="background-image: url('img/bb2.jpg'); height: 500px;" class="row">
			
				 <div class="col-sm-4">
				 	
				 </div>
				  <div class="col-sm-4">
				  	<br><br><br><br><br><br><br>
				 	<h2 style="font-family: Algerian;color: white;text-align: center;">Welcome to Medicare</h2>
				 	<br>
				 	<h5 style="text-align: center;font-family: Calibri;color: white;">Find And Book</h5>
				 	<br>
				 	

				 	<br><br><br>

				 </div>
				  <div class="col-sm-4">
				 	
				 </div>
		</div>
	</div>
	

<!-- For Details  -->
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-1"></div>
		<div class="col-sm-6">
			<br><br><br>
			<h3 style="text-align: center;font-family: Cooper Black;font-size: 40px;">Instant appointment with doctors.Guaranteed.</h3>
			<br>
			<ul style="margin-left: 100px;font-family: Constantia;font-size: 25px;">
				<li> 100,000 Verified doctors </li> <br>
				<li> 3M+ Patient recommendations</li><br>
				<li>3M+ Patient recommendations </li>
			</ul>
		</div>
		<div class="col-sm-4">
			<br>
			<video width="400" height="400" autoplay loop muted>
			  <source src="img/demo.webm" type="video/mp4" />
			  <source src="movie.ogg" type="video/ogg" />
			 
			</video>
		</div>
	</div>
</div>
<br><br>


<div style="background-color: #f2f2f2;padding: 30px;" class="container-fluid">
	<div class="row">
		<div class="col-sm-1"></div>

		<div class="col-sm-4">
			<br>
			<video width="400" height="400" autoplay loop muted>
			  <source src="img/demo2.webm" type="video/mp4" />
			  <source src="img/demo2.ogg" type="video/ogg" />
			 
			</video>
		</div>
		<div class="col-sm-6">
			<br><br><br>
			<h3 style="text-align: center;font-family: Cooper Black;font-size: 40px;">Skip the waiting room.<br>
Consult with a doctor</h3>
			<br>
			<ul style="margin-left: 100px;font-family: Constantia;font-size: 25px;">
				<li> Fees starting at ₹99 </li> <br>
				<li> Verified doctors respond in 5 minutes</li><br>
				<li>100% Private and confidential</li>
			</ul>
		</div>
		
	</div>
</div>



<!--  -->
<br><br>
<div class="container">
	<div class="row">

		<div class=" demo col-sm-6">
			<div style="border-radius: 20px;border:1px solid;box-shadow: 5px 10px #888888;" class="row">
				<div class="col-sm-6">
					<img  class="rounded" src="img/d1.jpg" width="260px" height="200px">
				</div>
				<div class=" col-sm-6">
					
					<h3>Find Doctors Near You</h3> <br>
					<p>Select preffered Doctor and time slot to book an in clinic</p>

					<a href="doctors.php"><button class="btn btn-success">Book Now</button></a>
				</div>
			</div>
		</div>


		<div class=" col-sm-6">
			<div style="border-radius: 20px;border:1px solid;margin-left: 20px;box-shadow: 5px 10px #888888;" class="demo2 row">
				<div class=" col-sm-6">
					<img  class="rounded" src="img/d2.jpg" width="260px" height="200px">
				</div>
				<div  class=" col-sm-6">
					
					<h3>Doctor's Online Now</h3> <br>
					<p>Tell Us Your health concern and will be asign you a top doctor in 60s </p>

					<a href="consult.php"><button class="btn btn-success">Consult Now</button></a>
				</div>
			</div>
		</div>
	</div>
</div>
<br><br><br><br>

<div class="container-fluid">
	<div style="padding: 40px;background-color: #f2f2f2;" class="row">
		<div class="col-sm-12">
			<h3>Consult top doctors online for any health concern</h3>
			<p>Find experienced doctors across all specialties</p>

			<div class="row">
				<div class="col-sm-3">
				<img src="img/c1.jpg" class="rounded-circle" width="200px" height="200px">
				<h4 >Pregnancy Problem</h4>
			</div>

			<div class="col-sm-3">
				<img src="img/c2.png" class="rounded-circle" width="200px" height="200px">
				<h4>Acne,pimple & Skin Problem</h4>
			</div>

			<div class="col-sm-3">
				<img src="img/c3.png" class="rounded-circle" width="200px" height="200px">
				<h4>Cold & Fever Problem</h4>
			</div>

			<div class="col-sm-3">
				<img src="img/c4.png" class="rounded-circle" width="200px" height="200px">
				<h4>small baby Problem</h4>
			</div>


			</div>
		</div>
		
	</div>
</div>

<br>
<div class="container">
	<h4 style="text-align: center;">Our Doctors says it  !</h4><br>
	<div class="row">

		<div class="col-sm-6">
			<div class="card bg-primary text-white">
			    <div style="height: 80px;" class="card-body"></div>
			</div>
			<div class="card bg-default">
			    <div class="card-body"> 
			    	<center><img style="margin-top: -100px;" class="rounded-circle" src="img/demo.jpg" width="100px" height="100px"> </center>
			    	<h5 style="text-align: center;">Dr.Saniket Khabale </h5>
			    	<h6> <span style="font-size: 30px;">"</span> There is no reason to panic. With proper precautions you can protect yourself, your family, your communities and our patients. Here are some tips to stay safe.  </h6>
			    </div>
			</div>
		</div>

		<div class="col-sm-6">
			<div class="card bg-warning text-white">
			    <div style="height: 80px;" class="card-body"></div>
			</div>
			<div class="card bg-default">
			    <div class="card-body"> 
			    	<center><img style="margin-top: -100px;" class="rounded-circle" src="img/photo.jpg" width="100px" height="100px"> </center>
			    	<h5 style="text-align: center;">Dr.Onkar Chavan</h5>
			    	<h6> <span style="font-size: 30px;">"</span> Wear a mask. My mask protects you and your mask protects me. Keep your mask in place at all times, covering your nose and chin.Be Careful.. </h6>
			    </div>
			</div>
		</div>



	</div>
</div>
<br>
<?php
include("footer.php");
?>
</body>
</html>