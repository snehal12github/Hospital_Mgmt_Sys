<?php
include("navbar.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-1">
			</div>
			<div class="col-sm-2">
				<form action="" method="post">
				
				
			</div>

			<div style="margin-left: -30px" class="col-sm-3">
				
				<input class="form-control" type="text" name="search" placeholder="Search By Doctor,Hospital">
				
			</div>

			<div class="col-sm-1">
				<button style="margin-left: -50px;" type="submit" name="find" class="btn btn-success">Search</button>
			</div>
			</form>
		</div>
	</div>
<br>
<div class="container-fluid">
	<div style="background-color: #4242f5;" class="row">
		<div class="col-sm-6">
			
				<h4 style="color: white;text-align: center;margin-top:100px;">GoodBye Problems</h4>
				<h2 style="color: white;text-align: center;">Say Hello To Doctors</h2>
				<hr>
				<p style="color: white;text-align: center;">24/7 Consultancy, Anytime Anywhere  </p>
			</div>

			<div class="col-sm-6">
				<img style="padding:20px" src="img/chatting.png" width="500px" height="300px" >
			</div>
		</div>
	
</div>


<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<br>
				<h4 style="text-align: center;"> Top Doctors</h4>
				<hr>
			</div>
				

				<?php
				
				if(isset($_POST["find"]))
				{
					$search=$_POST["search"];
					$select="select * from user where user_type='doctor' AND name like '$search%' OR type_doctor like '$search%' OR hospital like '$search%' ";
					 $query=mysqli_query($con,$select);
					
							 while($a=mysqli_fetch_array($query))
							 {
							 	$dname=$a["name"];
							 	$address=$a["address"];
							 	 $uname=$a["username"];
							 	 $email=$a["email"];
							 	 $pass=$a["password"];
							 	 $dtype=$a["type_doctor"];
							 	 $img=$a["image"];
							 	  $hospital=$a["hospital"];
							 


								 echo "
								
								 	<div style='padding:20px;' class='col-sm-4'>
					 		<div class='container-fluid'>
							    <div class='row'>
							        <div style='background-image: linear-gradient(#009FFF, #ec2F4B);height: 50px;' class='col-sm-12'>
							            <h4 style='color: white;text-align: center;''>$hospital</h4>
							        </div>
							       
							              <div class='col-sm-4'>
							                <img style='margin-top: 0px;'' class='rounded-circle' src='image/$img' height='150px' width='140px'>
							              </div>

							              <div class='col-sm-8'>
							              <br>
							                <h6>Name : $dname</h6> <br>
							                <h6> Expert In : $dtype </h6> <br>
							                <h6> Address  : $address </h6> <br>
							                
							              </div>
							              <div class='col-sm-12'>
							             <a href='chat.php?cid=$uname'><button class='btn btn-info form-control'> Consult With Doctor </button> </a>
							              </div>
							         
							    </div>
							    </div> 
					 	</div>
								
								 ";
								}
				}
				else
				{
					
					$select="select * from user where user_type='doctor'  ORDER BY RAND() LIMIT 4;";
					 $query=mysqli_query($con,$select);
					
							 while($a=mysqli_fetch_array($query))
							 {
							 	$dname=$a["name"];
							 	$address=$a["address"];
							 	 $uname=$a["username"];
							 	 $email=$a["email"];
							 	 $pass=$a["password"];
							 	 $dtype=$a["type_doctor"];
							 	 $img=$a["image"];
							 	  $hospital=$a["hospital"];
							 


								 echo "
								
								 	<div style='padding:20px;' class='col-sm-4'>
					 		<div class='container-fluid'>
							    <div class='row'>
							        <div style='background-image: linear-gradient(#009FFF, #ec2F4B);height: 50px;' class='col-sm-12'>
							            <h4 style='color: white;text-align: center;''>$hospital</h4>
							        </div>
							       
							              <div class='col-sm-4'>
							                <img style='margin-top: 0px;'' class='rounded-circle' src='image/$img' height='150px' width='140px'>
							              </div>

							              <div class='col-sm-8'>
							              <br>
							                <h6>Name : $dname</h6> <br>
							                <h6> Expert In : $dtype </h6> <br>
							                <h6> Address  : $address </h6> <br>
							                
							              </div>
							              <div class='col-sm-12'>
							             <a href='chat.php?cid=$uname'><button class='btn btn-info form-control'> Consult With Doctor </button> </a>
							              </div>
							         
							    </div>
							    </div> 
					 	</div>
								
								 ";
								}
				}
				?>

				
			</div>
			
		</div>
	</div>
	<br><br>

<div class="container-fluid">
		<div class="row">
			<img src="img/consult.png" width="100%">
		</div>
	</div>
	

<div class="container-fluid">
	<div style="padding: 40px;background-color: #f2f2f2;" class="row">
		<div class="col-sm-12">
			<h3>Book Appoitment top doctors online for any health concern</h3>
			<p>Find experienced doctors across all specialties</p>

			<div class="row">
				<a style="text-decoration: none;color: black;" href="display2.php?id=genral">
				<div class="col-sm-3">
				<img src="img/doc1.jpg" class="rounded-circle" width="200px" height="200px">
				<h4 >Genral Doctors</h4>
				</a>
			</div>

			<a style="text-decoration: none;color: black;" href="display2.php?id=dentist">
			<div class="col-sm-3">
				<img src="img/doc2.jpg" class="rounded-circle" width="200px" height="200px">
				<h4>Dental Problem</h4>
				</a>
			</div>

			<a style="text-decoration: none;color: black;" href="display2.php?id=gynaecologist">
			<div class="col-sm-3">
				<img src="img/doc3.jpg" class="rounded-circle" width="200px" height="200px">
				<h4>Gynecologist </h4>
				</a>
			</div>

			<a style="text-decoration: none;color: black;" href="display2.php?id=childern">
			<div class="col-sm-3">
				<img src="img/doc7.jpg" class="rounded-circle" width="200px" height="200px">
				<h4>Children Doctors</h4> 
				</a>
			</div>

			</div>


			<div style="margin-top: 40px;" class="row">

				<a style="text-decoration: none;color: black;" href="display2.php?id=dermatology">
			<div class="col-sm-3">
				<img src="img/doc3.jpg" class="rounded-circle" width="200px" height="200px">
				<h4>dermatology </h4>
				</a>
			</div>


			<a style="text-decoration: none;color: black;" href="display2.php?id=cardiology">
			<div class="col-sm-3">
				<img src="img/hart.png" class="rounded-circle" width="200px" height="200px">
				<h4>cardiology  </h4>
				</a>
			</div>

			<a style="text-decoration: none;color: black;" href="display2.php?id=neurologists">
			<div class="col-sm-3">
				<img src="img/doc6.jpg" class="rounded-circle" width="200px" height="200px">
				<h4>Neurologists   </h4>
				</a>
			</div>

			<a style="text-decoration: none;color: black;" href="display2.php?id=otolaryngology">
			<div class="col-sm-3">
				<img src="img/doc8.jpg" class="rounded-circle" width="200px" height="200px">
				<h4>OTOLARYNGOLOGY</h4>
				</a>
			</div>

			</div>

		</div>
		
	</div>
</div>


<div class="container-fluid">
		<div class="row">
			<img src="img/consult2.png" width="100%">
		</div>
	</div>

<br><br>
<div class="container">
	<h4 style="text-align: center;">Our Doctors says it  !</h4><br>
	<div class="row">

		<div class="col-sm-6">
			<div class="card bg-primary text-white">
			    <div style="height: 80px;" class="card-body"></div>
			</div>
			<div class="card bg-default">
			    <div class="card-body"> 
			    	<center><img style="margin-top: -100px;" class="rounded-circle" src="img/mayuri.jpg" width="100px" height="100px"> </center>
			    	<h5 style="text-align: center;">Dr.Mayuri Patil </h5>
			    	<h6> <span style="font-size: 30px;">"</span> There is no reason to panic. With proper precautions you can protect yourself, your family, your communities and our patients. Here are some tips to stay safe.  </h6>
			    </div>
			</div>
		</div>

		<div class="col-sm-6">
			<div class="card bg-warning text-white">
			    <div style="height: 80px;" class="card-body"></div>
			</div>
			<div class="card bg-default">
			    <div class="card-body"> 
			    	<center><img style="margin-top: -100px;" class="rounded-circle" src="img/nil.jpg" width="100px" height="100px"> </center>
			    	<h5 style="text-align: center;">Dr.Nilesh Khatavkar</h5>
			    	<h6> <span style="font-size: 30px;">"</span> Wear a mask. My mask protects you and your mask protects me. Keep your mask in place at all times, covering your nose and chin.Be Careful.. </h6>
			    </div>
			</div>
		</div>



	</div>
</div>
<br><br>
<?php
include("footer.php");
?>

</body>
</html>