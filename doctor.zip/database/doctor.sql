-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2021 at 03:42 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctor`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_appoitment`
--

CREATE TABLE `book_appoitment` (
  `id` int(11) NOT NULL,
  `doctor` text NOT NULL,
  `patient_id` text NOT NULL,
  `patient` text NOT NULL,
  `p_mobile` text NOT NULL,
  `book_date` date NOT NULL,
  `time_from` int(11) NOT NULL,
  `am` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_appoitment`
--

INSERT INTO `book_appoitment` (`id`, `doctor`, `patient_id`, `patient`, `p_mobile`, `book_date`, `time_from`, `am`, `date`) VALUES
(1, 'rohit', '0', 'rohit', '9175764998', '2021-08-24', 10, 'am', '2021-08-19'),
(2, 'rohit', 'arjun pawar', 'saniket khabale', '9175764998', '2021-08-21', 12, 'pm', '2021-08-19');

-- --------------------------------------------------------

--
-- Table structure for table `buyed`
--

CREATE TABLE `buyed` (
  `id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `buyer` text NOT NULL,
  `address` text NOT NULL,
  `mobile` text NOT NULL,
  `time` date NOT NULL,
  `seller` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buyed`
--

INSERT INTO `buyed` (`id`, `p_id`, `quantity`, `total`, `buyer`, `address`, `mobile`, `time`, `seller`) VALUES
(3, 2, 10, 120, 'arjun pawar', '\r\n	tasgaon						', '7558287516', '2021-05-14', 'rohitdada'),
(4, 2, 1207, 14484, 'arjun pawar', 'qefdawfszrfv\r\n							', '7558287516', '2021-08-19', 'rohitdada');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `p_id` text NOT NULL,
  `buyer` text NOT NULL,
  `date` date NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `msg_from` text NOT NULL,
  `msg_to` text NOT NULL,
  `msg` text NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `msg_from`, `msg_to`, `msg`, `date`, `time`) VALUES
(1, 'sani', 'rohit', 'hiii', '2021-05-07', '10:48:32'),
(2, 'arjun pawar', 'rohit', 'hello', '2021-05-07', '13:02:24'),
(3, 'rohit', 'arjun pawar', 'hii', '2021-05-07', '13:02:53'),
(4, 'rohit', 'arjun', 'good morning', '2021-05-07', '13:14:35'),
(5, 'arjun pawar', 'rohit', 'good Morning', '2021-05-07', '13:16:22'),
(6, 'rohit', 'arjun pawar', 'good Night', '2021-05-07', '13:16:31'),
(7, 'arjun pawar', 'rohit', 'hii', '2021-05-07', '14:03:09'),
(8, 'arjun pawar', 'rohit', 'fine', '2021-05-07', '14:13:04'),
(9, 'rohit', 'arjun pawar', 'zop gp', '2021-05-07', '14:13:13'),
(10, 'arjun pawar', 'rohit', 'nahi zopat ja', '2021-05-07', '14:13:56'),
(11, 'arjun pawar', 'rohit', 'tu zop ja', '2021-05-07', '14:14:06'),
(12, 'arjun pawar', 'rohit', 'ka', '2021-05-07', '14:14:22'),
(13, 'arjun pawar', 'rohit', 'kadhi', '2021-05-07', '14:14:36'),
(14, 'arjun pawar', 'rohit', 'ha', '2021-05-07', '14:14:43'),
(15, 'arjun pawar', 'rohit', 'jsdhb s dbci s dbcui uadcui   adc oaoiac ', '2021-05-07', '14:15:56'),
(16, 'arjun pawar', 'rohit', 'hii', '2021-05-07', '14:22:36'),
(17, 'arjun pawar', 'rohit', 'hello', '2021-05-07', '14:22:41'),
(18, 'rohit', 'saniket khabale', 'good morning', '2021-05-07', '14:22:47'),
(19, 'arjun pawar', 'rohit', 'by', '2021-05-07', '14:23:43'),
(20, 'arjun pawar', 'saniket khabale', 'hiii', '2021-05-12', '09:43:52'),
(21, 'saniket khabale', 'rohit', 'hello', '2021-05-12', '10:00:49'),
(22, 'saniket khabale', 'arjun pawar', 'hello', '2021-05-12', '10:17:12'),
(23, 'saniket khabale', 'arjun pawar', 'good morning', '2021-05-12', '10:17:18');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `disease` text NOT NULL,
  `dis` text NOT NULL,
  `p1` text NOT NULL,
  `p2` text NOT NULL,
  `p3` text NOT NULL,
  `price` text NOT NULL,
  `quentity` text NOT NULL,
  `regtime` date NOT NULL,
  `seller` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`id`, `name`, `disease`, `dis`, `p1`, `p2`, `p3`, `price`, `quentity`, `regtime`, `seller`) VALUES
(1, 'crocin max', 'headache', 'most used medicine for headache', 'c1.jpg', 'c3.jpg', 'c2.jpg', '90', '100', '2021-05-12', 'rohitdada'),
(2, 'paracitomol', 'fever and cold', 'its best medicine for cold', 'p1.png', 'p2.jpg', 'p3.jpg', '12', '100', '2021-05-12', 'rohitdada'),
(3, 'arjun pawar', 'headache', 'most used medicine for headache', 'WhatsApp-Image-2021-08-19-at-5.04.10-PM-ConvertImage.jpg', 'WhatsApp Image 2021-08-19 at 5.04.10 PM.jpeg', 'WhatsApp-Image-2021-08-19-at-5.04.10-PM-ConvertImage.jpg', '10000', '10', '2021-08-19', 'demo');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `email` text NOT NULL,
  `type_doctor` text NOT NULL,
  `password` text NOT NULL,
  `user_type` text NOT NULL,
  `date` date NOT NULL,
  `price` text NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `image` text NOT NULL,
  `hospital` text NOT NULL,
  `mobile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `type_doctor`, `password`, `user_type`, `date`, `price`, `name`, `address`, `image`, `hospital`, `mobile`) VALUES
(1, 'arjun pawar', 'arjun@gmail.com', '', '$2y$10$5oD0lTeK6rrj1QeVXCWdyeTD9TCOhQmDu4ui65yMYunD62g.0Oer6', 'User', '2021-05-06', '', '', '', '', '', ''),
(2, 'saniket khabale', 'sanikhabale@gmail.com', 'gynaecologist', '$2y$10$/Lcq3DbbkCCNsA0LMfAoXeSrKT0K0w0jTgBNDd4jpgZZ.GoeCo2Qa', 'doctor', '2021-05-06', '90', 'saniket khabale', 'Turchi', 'p2.jpg', 'bharti hospital sangli', ''),
(3, 'rohit', 'rohit@gmail.com', 'dentist', '$2y$10$buCf.zHh6EDvxEYqllDx4ut3/RmgGzhO.JQjj3anRTr77AbJMlNQO', 'doctor', '2021-05-06', '100', 'rohit jadhav', 'Turchi', 'IMG_1993.JPG', 'shpsdh hospital', ''),
(4, 'rohitdada', 'sanikhabale@gmail.com', '', '$2y$10$yDwZmNkt2xiRJdu.o2DB3edYXO4pKg8ohCGWtB05d3vbtFqR8QLUS', 'medical', '2021-05-12', '', 'rohit ', '			Turchi		', '', '', '08421739251'),
(6, 'demo', 'demo@gmail.com', '', '$2y$10$Up9Vj3YkDxARxB5RPypaju0hpqSz5IiPufJ3IPgqweh5aafiTNHue', 'medical', '2021-08-19', '', '', '', '', '', ''),
(7, 'graps', 'good@gmail.com', '', '$2y$10$n/XLSA2sbICOI8UTloiOaeRsWuK2tZxe3qnVfICaD6ZBkY..3TkRi', 'doctor', '2021-08-19', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_appoitment`
--
ALTER TABLE `book_appoitment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buyed`
--
ALTER TABLE `buyed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_appoitment`
--
ALTER TABLE `book_appoitment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `buyed`
--
ALTER TABLE `buyed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
