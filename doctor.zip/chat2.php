<?php
include("navbar.php");
if($_SESSION["username"]=="")
{
	echo "<script> alert('Login First') </script>";
	echo "<script> window.location.href=('consult.php'); </script>";
}
?>
<div class="container-fluid">
	<div class="row">
	<div class="col-sm-2">
		
			
		 
			<br/><br/>
		  <form>
				<a href="admin.php?id=1"  style="color:green"><button type="button" class="btn btn-outline-primary form-control"><i class="fa fa-dashboard"></i> Dashboard</button></a>
			  <br /><br />
			  <a href="admin.php?id=2"  style="color:green" ><button type="button"  class="btn btn-outline-primary form-control"><i class="fa fa-edit"></i>My Orders </button></a>
			  <br /><br />
			  
			   <a href="admin.php?id=3"  style="color:green" ><button type="button"  class="btn btn-outline-primary form-control"><i class="fa fa-edit"></i> My Appoitment </button></a>
			   
			    <br /><br />
			  
			   <a href="admin.php?id=4"  style="color:green" ><button type="button"  class="btn btn-outline-primary form-control"><i class="fa fa-edit"></i>Edit Profile </button></a>
			   
			  <br /><br />
			 
			  
			  <a href="admin.php?id=5"  style="color:green"><button type="button"  class="btn btn-outline-primary form-control"><i class="fa fa-envelope"></i> Chat </button></a>
			 
			  <br /><br />
			  
			  
				<a href="logout.php" style="color:green"><button type="button" class="btn btn-outline-primary form-control"><i class="fa fa-power-off"></i> Log Out</button></a>
			  </form>
	

	</div>

	<div class="col-sm-10">
		<br/><br/>
		<?php
		$u=$_SESSION["username"];
		$select5="select * from user where username='$u'";
			$query5=mysqli_query($con,$select5);
			while($s5=mysqli_fetch_array($query5))
			{
			   
				 $id=$s5["id"];

			}
		/*
		$select="select * from laptop";
		$query=mysqli_query($con,$select);
		$count=mysqli_num_rows($query);

		$select2="select * from buy where buyer='$u'";
		$query2=mysqli_query($con,$select2);
		$count2=mysqli_num_rows($query2);

		$select3="select * from laptop where user_id='$id'";
		$query3=mysqli_query($con,$select3);
		$count3=mysqli_num_rows($query3);

		$select4="select * from offer where user_id='$id'";
		$query4=mysqli_query($con,$select4);
		$count4=mysqli_num_rows($query4);
		
*/




		@$a=$_GET["id"];
					
					if($a==1)
					{
					
					echo "
					
					
					
						
				<div class='container-fluid'>
					<div class='row'>
					<br/> <br> <br> <br> <br> <br> 
						<div style='width:200px;height:220px; background-color:#F5F5F5;margin-left:15px' class=' col-sm-2'>
							
							<center><img src='img/order.png' class='img-rounded' width='130px' height='100px' / style='margin-top:10px'></center>


							
							
							<h3 style='text-align:center;color:black;font-size:24px; margin-top:10px'> My Orders</h3>
							
							<h3 style='text-align:center;font-size:30px'> @count </h3>
						</div>


						<div style='width:200px;height:220px; background-color:#F5F5F5;margin-left:15px' class=' col-sm-2'>
							
							<center><img src='img/app.jpg' class='img-rounded' width='130px' height='100px' / style='margin-top:10px'></center>


							
							
							<h3 style='text-align:center;color:black;font-size:24px; margin-top:10px'> Appoitment</h3>
							
							<h3 style='text-align:center;font-size:30px'> @count </h3>
						</div>


						<div style='width:200px;height:220px; background-color:#F5F5F5;margin-left:15px' class=' col-sm-2'>
							
							<center><img src='img/chat.png' class='img-rounded' width='130px' height='100px' / style='margin-top:10px'></center>


							
							
							<h3 style='text-align:center;color:black;font-size:24px; margin-top:10px'> My Chat</h3>
							
							<h3 style='text-align:center;font-size:30px'> @count </h3>
						</div>



						
						
					</div>
					</div>
					
					";
					}
					
					
					
					
					
					if($a==2)
					{
						include ("myorder.php");
					}
					else if($a==3)
					{
						include("user_appoitment.php");
					}
					
					
					
					else if($a==4)
					{
						include("edit.php");
					}
					
					
					else if($a==5)
					{
						
						include("message.php");
						
					}
					
					
					?>

<div class="row">
			<?php 

			 $cid=$_GET["cid"];


								 $select6="select * from user where username='$cid'";
								 $query6=mysqli_query($con,$select6);
								 while ($c=mysqli_fetch_array($query6))
								  {
								 	  $uname=$c["username"];
								 	  $img=$c["image"];
								 }


								echo "

								<div class='col-sm-1'>
								</div>
								<div style='border:1px solid black;padding:20px;' class='col-sm-6'>
									<div class='row'>
										<a href='user.php?id=5'><img class='rounded-circle' src='image/$img' width='100px' height='70px'> </a><span style='text-align:center;font-size:30px;margin-left:100px'> 
										$uname </span>
										<hr>

									</div>
									<br>

									<div style='height:400px;overflow: scroll;' class='row'>
							";
							$msg_sender=$_SESSION["username"];
							$select8="select * from chat where msg_from='$msg_sender' AND msg_to='$uname' OR msg_from='$uname' AND msg_to='$msg_sender'";
							$query8=mysqli_query($con,$select8);
							while($m=mysqli_fetch_array($query8))
							{
								  $msg=$m["msg"];
								 $from=$m["msg_from"];
								 $to=$m["msg_to"];

								 if($from==$_SESSION["username"])
								 {  
								 
								 	echo "	<div style='' class='container'>
								 			 <h7> $msg </h7> 
								 		</div>
								 		";
								 	
								 	
								 }
								 elseif($from!=$_SESSION["username"])
								 {
								 	
								 		echo "	<div style='margin-left:400px;' class='container'>
								 			 <h7> $msg </h7> 
								 		</div>
								 		";
								 	
								 	
								 }
										
							}  
							

										echo "
									</div>
										<form action='' method='post'>
										<hr>
										<div class='row'>
											<div class='col-sm-9'>
												<input name='msg' class='form-control' type='text' >
											</div>
											<div class='col-sm-3'>
												<input style='margin-left:-20px;'  name='send' class='btn btn-success' type='submit' value='send' >
											</div>
										</div>
										</form>

								</div>
								<div class='col-sm-3'>
								</div>


								"; 	



							
			?>
	</div>

</div>

<?php
	
	if(isset($_POST["send"]))
	{
		$msg=$_POST["msg"];
		$msg_sender=$_SESSION["username"];
		 $uname;

		$insert="insert into chat(msg_from,msg_to,msg,date,time) values('$msg_sender','$uname','$msg',NOW(),NOW())";
		$query7=mysqli_query($con,$insert);

		if($query7)
		{
			echo "<script>window.location.href='chat.php?cid=$cid'; </script>";
			echo "<script> alert('hiii') ;</script>";
		}
	}
?>